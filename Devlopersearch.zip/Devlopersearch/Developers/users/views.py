
from django.shortcuts import render,redirect
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth.models import User
from .models import Profiles, Skill, Message
from django.db.models import Q
from .forms import CustomUserCreationForm
from .forms import profileForm, skillForm, MessageForm
from .utils import paginateProfiles, searchProfiles
# Create your views here.
def profiles(request):
    profiles, search_query = searchProfiles(request)
    customIndex, profiles = paginateProfiles(request, profiles,6)
    context = {'profile': profiles, 'search_query':search_query, 'customIndex': customIndex}
    return render(request, 'users/profiles.html',context)

def userProfile(request,pk):
    profile = Profiles.objects.get(id=pk)
    topSkills = profile.skill_set.exclude(descriptions__exact="")
    otherSkills = profile.skill_set.filter(descriptions="")
    context = {'profile': profile,'topSkills':topSkills,'otherSkills':otherSkills}
    return render(request,'users/user-profile.html',context)

def userlogin(request):
    if request.user.is_authenticated:
        return redirect('profiles')
    if request.method == "POST":
        username = request.POST['username'].lower()
        password = request.POST['password']

        try:
            user = User.objects.get(username=username)
        except:
            messages.error(request,"Username doesn't Exits !!!")
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect(request.GET['next'] if 'next' in request.GET else 'userAccount')
        else:
            messages.error(request,"Username or Password is Invalid")
    return render(request,'users/login_register.html')

def userlogout(request):
    logout(request)
    messages.info(request,"Username was Sucessfully logout !!!")
    return redirect('userlogin')

def userRegister(request):
    page = 'register'
    form = CustomUserCreationForm()
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.username = user.username.lower()
            user.save()
            messages.success(request,"Successfully Register user !!!")
            login(request,user)
            return redirect('editAccount')
        else:
            messages.success(request, "An Error has been Occured")
    context = {'page':page, 'form': form}
    return render(request, 'users/login_register.html',context)

@login_required(login_url='userlogin')
def userAccount(request):
    profile = request.user.profiles
    skills = profile.skill_set.all()
    project = profile.project_set.all()
    context = {'profile':profile,'skills':skills,'project':project}
    return render(request,'users/account.html',context)

@login_required(login_url="userlogin")
def editAccount(request):
    profile = request.user.profiles
    form = profileForm(instance=profile)
    if request.method == 'POST':
        form = profileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            return redirect('userAccount')
    context = {'form': form}
    return render(request,'users/profile_form.html', context)

@login_required(login_url='userlogin')
def createSkill(request):
    profile = request.user.profiles
    form = skillForm()
    if request.method == 'POST':
        form = skillForm(request.POST)
        if form.is_valid():
            skill = form.save(commit=False)
            skill.owner = profile
            skill.save()
            messages.success(request,"Successfully Added Skill !!!")
            return redirect('userAccount')
    context = {'form': form}
    return render(request, 'users/skill_form.html', context)

@login_required(login_url='userlogin')
def updateSkill(request,pk):
    profile = request.user.profiles
    skill = profile.skill_set.get(id=pk)
    form = skillForm(instance=skill)
    if request.method == "POST":
        form = skillForm(request.POST,instance=skill)
        if form.is_valid():
            form.save()
            messages.success(request,"Successfully Updated Skill !!!")
            return redirect('userAccount')

    context = {'form': form}
    return render(request,'users/skill_form.html', context)

@login_required(login_url='userlogin')
def deleteSkill(request,pk):
    profile = request.user.profiles
    skill = profile.skill_set.get(id=pk)
    if request.method == 'POST':
        skill.delete()
        messages.success(request,"Successfully Deleted Skill !!!")
        return redirect('userAccount')
    context = {'object': skill}
    return render(request,'delete_template.html', context)


def inbox(request):
    profile = request.user.profiles
    messageRequest = profile.messages.all()
    unreadCount = messageRequest.filter(is_read=False).count()
    context = {'messageRequest':messageRequest, 'unreadCount':unreadCount}
    return render(request, 'users/inbox.html', context)

def viewMessages(request, pk):
    profile = request.user.profiles
    message = profile.messages.get(id=pk)
    if message.is_read == False:
        message.is_read = True
        message.save()
    context = {'message':message}
    return render(request, 'users/messages.html', context)

def sendMessage(request,pk):
    recipient = Profiles.objects.get(id=pk)
    form = MessageForm()
    try:
        sender = request.user.profiles
    except:
        sender = None
    if request.method == 'POST':
        form = MessageForm(request.POST)
        if form.is_valid():
            message = form.save(commit=False)
            message.sender = sender
            message.recipient = recipient
            
            if sender:
                message.name = sender.name
                message.email = sender.email
            message.save()
            messages.success(request,"Successfully Send Message !!!")
            return redirect('usersProfile', pk=recipient.id)
    context = {'recipient':recipient, 'form':form}
    return render(request, 'users/message_form.html', context)