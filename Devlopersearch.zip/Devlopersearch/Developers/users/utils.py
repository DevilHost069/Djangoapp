from .models import Profiles, Skill
from django.db.models import Q
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
def searchProfiles(request):
    search_query = ''
    if request.GET.get('search_query'):
        search_query = request.GET.get('search_query')
    skills = Skill.objects.filter(name__icontains=search_query)
    profiles = Profiles.objects.distinct().filter(
     Q(name__icontains=search_query) |
     Q(short_intro__icontains=search_query) |
     Q(skill__in=skills))
    return profiles, search_query

def paginateProfiles(request,profile,results):
    page = request.GET.get('page')
    results = 3
    paginator = Paginator(profile,results)
    try:
        profile = paginator.page(page)
    except PageNotAnInteger:
        page = 1
        profile = paginator.page(page)
    except EmptyPage:
        page = paginator.num_pages
        profile = paginator.page(page)
    leftIndex = (int(page) - 4)
    if leftIndex < 1:
        leftIndex = 1
    rightIndex = (int(page) + 5)
    if rightIndex > paginator.num_pages:
        rightIndex = paginator.num_pages + 1
    customIndex = range(leftIndex, rightIndex)

    return customIndex, profile