from django.urls import path
from . import views

urlpatterns = [
    path('userlogin', views.userlogin, name="userlogin"),
    path('userlogout/', views.userlogout, name="userlogout"),
    path('userRegister/', views.userRegister, name="userRegister"),
    path('userAccount/', views.userAccount, name="userAccount"),
    path('editAccount/', views.editAccount, name="editAccount"),
    path('createSkill/',views.createSkill, name="createSkill"),
    path('updateSkill/<str:pk>/', views.updateSkill, name='updateSkill'),
    path('deleteSkill/<str:pk>/', views.deleteSkill, name="deleteSkill"),
    path('', views.profiles, name="profiles"),
    path('users/<str:pk>/', views.userProfile, name="usersProfile"),
    path('inbox/', views.inbox, name="inbox"),
    path('viewMessages/<str:pk>/', views.viewMessages, name="viewMessages"),
    path('sendMessage/<str:pk>/', views.sendMessage, name="sendMessage")
]


