inputstr = input("Enter some text")
clearstr = inputstr.replace('dust', 'ClearFllor')
print(f"Output:-  {clearstr}")