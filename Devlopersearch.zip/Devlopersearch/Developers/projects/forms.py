from django.forms import ModelForm
from .models import Project, Review
from django import forms
class ProjectForm(ModelForm):
    class Meta:
        model = Project
        fields = ['title','featured_image', 'descriptions', 'demo_link', 'source_link', 'tags']
        widgets={
            # 'title':forms.TextInput(attrs={'class':'form-control'}),
            # 'featured_image':forms.FileInput(attrs={'class':'form-control'}),
            # 'descriptions':forms.TextInput(attrs={'class':'form-control'}),            
            # 'demo_link':forms.TextInput(attrs={'class':'form-control'}),
            # 'source_link':forms.TextInput(attrs={'class':'form-control'}),
            # 'tags':forms.TextInput(attrs={'class':'form-control'}),
            'tags': forms.CheckboxSelectMultiple(),
        }
    def __init__(self, *args, **kwargs):
        super(ProjectForm, self).__init__(*args,**kwargs)

        for name, field in self.fields.items():
            field.widget.attrs.update({'class': 'input'})



        # self.fields['title'].widget.attrs.update(
        #     {'class': 'input', 'placeholder':'Enter title'})

        # self.fields['descriptions'].widget.attrs.update(
        #     {'class': 'input', 'placeholder':'Write some things'}
        # )
class ReviewForm(ModelForm):
    class Meta:
        model = Review
        fields = ['value', 'body']

    labels = {
        'value': 'Place your Vote',
        'body': 'Add your Comment'
    }
    def __init__(self, *args, **kwargs):
        super(ReviewForm, self).__init__(*args,**kwargs)

        for name, field in self.fields.items():
            field.widget.attrs.update({'class': 'input'})